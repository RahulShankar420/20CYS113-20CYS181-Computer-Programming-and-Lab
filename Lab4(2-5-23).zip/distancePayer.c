#include<stdio.h>
#define WAGE 10
void main()
{
	int start,end,payment;
	printf("Enter the value when starting\n");
	scanf("%d",&start);
	printf("Enter the value when stopped \n");
	scanf("%d",&end);
	 payment=(end-start)*WAGE;
	 printf("The payment is %d",payment);

}
