#include<stdio.h>
void main()
{
	int time;
	double temp;
	printf("Enter the time that has elapsed after power failure:\n");
	scanf("%d",&time);

	temp=(double)((4*time*time)/(time+2))-20;
	printf("The temperature in the freezer is %lf",temp);
}
