#include<stdio.h>
void main()
{
	double rate;
	int volume,time;
	printf("Enter the total quantity of fluid to be pumped in mls:\n");
	scanf("%d",&volume);
	printf("Enter the duration over which it should be supplied in hrs:\n");
	scanf("%d",&time);

	time=time*60;
	rate=(double)volume/time;
	printf("Volume:%d\n",volume);
	printf("Rate of distribution:%lf per min",rate);
}
